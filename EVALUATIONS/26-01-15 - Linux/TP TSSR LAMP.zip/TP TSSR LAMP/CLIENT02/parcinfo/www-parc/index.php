<html>
	<head>
		<meta charset="utf-8" />
		<link rel="stylesheet" href="index.css" title="CSS global">
	</head>
	<body>
<?php	
	print ("<h1 align=center>Liste des PC</h1>");
	$server_ip = $_SERVER['SERVER_ADDR'];
	echo "<h2 align=center>SERVER $server_ip </h2>";

    // Connexion à la base de données
    $host = "localhost";
    $dbname = "parcinfo";
    $username = "adminfo";
    $password = "Reponse2025";
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);

    // Récupération des données de la table gpi_software
    $stmt = $pdo->prepare("SELECT namepc,namemod FROM gpi_computers, gpi_computermodels WHERE gpi_computers.idpc = gpi_computermodels.idmod");
    $stmt->execute();
    $res = $stmt->fetchAll();

    echo "<table align=center>";
    echo "<tr><th>Nom PC</th><th>MODELE</th></tr>";

foreach ( $res as $ligne ) {

						
        echo "<tr>";
        echo "<td>" . $ligne['namepc'] . "</td>";
        echo "<td>" . $ligne['namemod'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
		
print ("</font></BODY></HTML>");

?>