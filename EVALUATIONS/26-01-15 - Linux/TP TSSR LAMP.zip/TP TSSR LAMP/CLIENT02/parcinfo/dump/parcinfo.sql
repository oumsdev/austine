-- phpMyAdmin SQL Dump
-- version 3.3.9.2
-- http://www.phpmyadmin.net
--
-- Serveur: 127.0.0.1
-- Généré le : Dim 26 Juin 2011 à 16:55
-- Version du serveur: 5.5.10
-- Version de PHP: 5.3.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `parcinfo`
--

-- --------------------------------------------------------

--
-- Structure de la table `gpi_computermodels`
--

CREATE TABLE IF NOT EXISTS `gpi_computermodels` (
  `idmod` int(11) NOT NULL AUTO_INCREMENT,
  `namemod` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`idmod`)
) ENGINE=innodb  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=13 ;

--
-- Contenu de la table `gpi_computermodels`
--

INSERT INTO `gpi_computermodels` (`idmod`, `namemod`, `comment`) VALUES
(1, 'Dell Vostro 430', NULL),
(2, 'Dell Vostro 230ST', NULL),
(3, 'Dell OptiPlex 380', NULL),
(4, 'Dell Precision T7500', NULL),
(5, 'HP G5225fr', NULL),
(6, 'HP SG3-230FR-M', NULL),
(7, 'Dell Vostro 3500', NULL),
(8, 'Dell Vostro 3700', NULL),
(9, 'IBM X31', NULL),
(10, 'HP Pavilion 2100', NULL),
(11, 'Dell Poweredge T110', NULL),
(12, 'HP Superdome 2', NULL);

-- --------------------------------------------------------

--
-- Structure de la table `gpi_computers`
--

CREATE TABLE IF NOT EXISTS `gpi_computers` (
  `idpc` int(11) NOT NULL AUTO_INCREMENT,
  `namepc` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` year(4) DEFAULT NULL,
  `operatingsystemversions_id` int(11) NOT NULL DEFAULT '0',
  `operatingsystemservicepacks_id` int(11) NOT NULL DEFAULT '0',
  `os_license_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `computermodels_id` int(11) NOT NULL DEFAULT '0',
  `computertypes_id` int(11) NOT NULL DEFAULT '0',
  `ticket_tco` decimal(20,4) DEFAULT '0.0000',
  PRIMARY KEY (`idpc`)
) ENGINE=innodb  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=30 ;

--
-- Contenu de la table `gpi_computers`
--

INSERT INTO `gpi_computers` (`idpc`, `namepc`, `serial`, `otherserial`, `comment`, `date_mod`, `operatingsystemversions_id`, `operatingsystemservicepacks_id`, `os_license_number`, `computermodels_id`, `computertypes_id`, `ticket_tco`) VALUES
(1, 'PC01', 'AZQS-6783', NULL, NULL, 2018, 1, 3, 'AAAA-BBBB-CCCC-DDDD', 1, 1, 0.0000),
(2, 'PC02', 'AZQS-6784', NULL, NULL, 2018, 1, 3, 'AAAA-BBBB-CCCC-DDDE', 1, 1, 0.0000),
(3, 'PC03', 'AZQS-5478', NULL, NULL, 2010, 1, 2, 'AAAA-BBBB-CCCC-DDDF', 1, 1, 0.0000),
(4, 'PC04', 'AZQS-6785', NULL, NULL, 2018, 1, 3, 'AAAA-BBBB-CCCC-DDDG', 1, 1, 0.0000),
(5, 'PC05', 'AZQS-5479', NULL, NULL, 2018, 1, 2, 'AAAA-BBBB-CCCC-DDDH', 1, 1, 0.0000),
(6, 'PC06', 'AZQS-5480', NULL, NULL, 2018, 1, 4, 'AAAA-BBBB-CCCC-DDDI', 2, 1, 0.0000),
(7, 'PC07', 'AZQS-5481', NULL, NULL, 2019, 1, 4, 'AAAA-BBBB-CCCC-DDDJ', 3, 1, 0.0000),
(8, 'PC08', 'AZQS-5482', NULL, NULL, 2019, 1, 4, 'AAAA-BBBB-CCCC-DDDK', 3, 1, 0.0000),
(9, 'PC09', 'AZQS-5483', NULL, NULL, 2018, 2, 2, 'FFFF-BBBB-CCCC-DDDL', 4, 1, 0.0000),
(10, 'PC10', 'AZQS-5484', NULL, NULL, 2019, 2, 2, 'FFFF-BBBB-CCCC-DDDA', 4, 1, 0.0000),
(11, 'PC11', 'AZQS-5485', NULL, NULL, 2020, 1, 4, 'AAAA-BBBB-CCCC-DDDB', 5, 1, 0.0000),
(12, 'PC12', 'AZQS-5486', NULL, NULL, 2019, 1, 4, 'AAAA-BBBB-CCCC-DDDC', 5, 1, 0.0000),
(13, 'PC13', 'AZQS-5487', NULL, NULL, 2018, 1, 4, 'AAAA-BBBB-CCCC-DDDY', 5, 1, 0.0000),
(14, 'PC14', 'AZQS-5488', NULL, NULL, 2017, 1, 4, 'AAAA-BBBB-CCCC-DDDX', 5, 1, 0.0000),
(15, 'PC15', 'AZQS-5489', NULL, NULL, 2018, 1, 4, 'AAAA-BBBB-CCCC-DDDZ', 5, 1, 0.0000),
(16, 'PCP01', 'POIUI-1234', NULL, NULL, 2018, 2, 2, 'FFFF-BBBB-CCCC-DDDB', 7, 2, 0.0000),
(17, 'PCP02', 'POIUI-1235', NULL, NULL, 2018, 2, 2, 'FFFF-BBBB-CCCC-DDDC', 7, 2, 0.0000),
(18, 'PCP03', 'POIUI-1236', NULL, NULL, 2018, 2, 2, 'FFFF-BBBB-CCCC-DDDR', 8, 2, 0.0000),
(19, 'PCP04', 'POIUI-1237', NULL, NULL, 2020, 2, 2, 'FFFF-BBBB-CCCC-DDDT', 7, 2, 0.0000),
(20, 'PCP05', 'POIUI-1238', NULL, NULL, 2020, 2, 2, 'FFFF-BBBB-CCCC-DDDY', 7, 2, 0.0000),
(21, 'PCP06', 'POIUI-1239', NULL, NULL, 2019, 1, 4, 'AAAA-BBBB-CCCC-HHHH', 9, 2, 0.0000),
(22, 'PCP07', 'POIUI-1240', NULL, NULL, 2018, 2, 2, 'FFFF-BBBB-CCCC-DDDQ', 8, 2, 0.0000),
(23, 'PCP08', 'POIUI-1241', NULL, NULL, 2018, 2, 2, 'FFFF-BBBB-CCCC-DDDY', 10, 2, 0.0000),
(24, 'SRV01', 'KJHGI-0987', NULL, NULL, 2018, 3, 2, 'FFFF-BBBB-CCCC-EEEEY', 11, 3, 0.0000),
(25, 'SRV02', 'KJHGI-0988', NULL, NULL, 2018, 6, 1, '', 11, 3, 0.0000),
(26, 'SRV03', 'KJHGI-0989', NULL, NULL, 2018, 6, 1, '', 11, 3, 0.0000),
(27, 'SRV04', 'KJHGI-0990', NULL, NULL, 2010, 3, 2, 'FFFF-BBBB-CCCC-WWWY', 12, 3, 0.0000),
(28, 'SRV05', 'KJHGI-0990', NULL, NULL, 2018, 4, 2, 'FFFF-BBBB-CCCC-BBBBY', 11, 3, 0.0000),
(29, 'PCP09', 'POIUI-1241', NULL, NULL, 2017, 5, 1, '', 10, 2, 0.0000);

