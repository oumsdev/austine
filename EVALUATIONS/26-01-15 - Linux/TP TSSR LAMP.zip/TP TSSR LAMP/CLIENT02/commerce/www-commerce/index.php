<html>
	<head>
		<meta charset="utf-8" />
		<link rel="stylesheet" href="index.css" title="CSS global">
	</head>
	<body>
<?php	
	print ("<h1 align=center>Liste des Clients</h1>");
	$server_ip = $_SERVER['SERVER_ADDR'];
	echo "<h2 align=center>SERVER $server_ip </h2>";

    // Connexion à la base de données
    $host = "localhost";
    $dbname = "commerce";
    $username = "adminco";
    $password = "Reponse2025";
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);

    // Récupération des données de la table client
    $stmt = $pdo->prepare("SELECT * FROM client");
    $stmt->execute();
	$res = $stmt->fetchAll();
foreach ( $res as $ligne ) {

		$titre = $ligne['Titre'];
		$nom = $ligne['Nom'];
		$prenom = $ligne['Prenom'];									
		echo "$titre $nom $prenom<br>";
						
}
		
print ("</font></BODY></HTML>");

?>