-- MariaDB dump 10.19  Distrib 10.11.4-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: commerce
-- ------------------------------------------------------
-- Server version	10.11.4-MariaDB-1~deb12u1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `client`
--

DROP TABLE IF EXISTS `client`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client` (
  `NClient` tinyint(3) NOT NULL,
  `Titre` enum('Madame','Mademoiselle','Monsieur') DEFAULT NULL,
  `Nom` char(30) DEFAULT NULL,
  `Prenom` char(30) DEFAULT NULL,
  `Adresse` char(100) DEFAULT NULL,
  `CodePostal` float(5,0) unsigned zerofill DEFAULT NULL,
  `Ville` char(20) DEFAULT NULL,
  `Observation` text DEFAULT NULL,
  PRIMARY KEY (`NClient`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client`
--

LOCK TABLES `client` WRITE;
/*!40000 ALTER TABLE `client` DISABLE KEYS */;
INSERT INTO `client` VALUES
(1,'Monsieur','Pore','Fred','rue Barbe',75001,'Paris','No comment'),
(2,'Madame','Brel','Francisca','rue Minant',02100,'Saint-Quentin','No Comment'),
(3,'Mademoiselle','Delune','Claire','rue Zai',59700,'Lille','Promo 50%'),
(4,'Monsieur','Revienkantuveu','Arthur','rue Tilant',75002,'Paris','Promo 50%'),
(5,'Madame','Zeblouse','Agathe','Rue Stique',64000,'Pau','Promo 25%'),
(6,'Monsieur','Pastamoto','Alphonse','Rue Gissant',69005,'Lyon','Promo 15%'),
(7,'Mademoiselle','Lot','Samantha','rue Dimentaire',75008,'Paris','No comment'),
(8,'Monsieur','Eurindelaibil','Marc','Rue Matisme',79000,'Niort','No comment'),
(9,'Monsieur','Duktible','Désirée','Rue Bie',75015,'Paris','No comment'),
(10,'Madame','Cor','Ada','Rue Cher',33000,'Bordeaux','No comment'),
(11,'Mademoiselle','Mort','Adèle','Rue Desse',92000,'Nanterre','No comment'),
(12,'Monsieur','Frigoskeutapri','Roméo','Rue Gueubi',92700,'Colombes','Promo 39 %'),
(13,'Monsieur','Menvussa','Gérard','Rue Gir',93300,'Aubervilliers','Promo 30 %'),
(14,'Monsieur','Terrieur','Alain','Rue Meur',92230,'Genevilliers','No comment'),
(15,'Monsieur','Terrieur','Alex','Rue Meur',92230,'Genevilliers','Contacter en Juillet'),
(16,'Madame','Matinai','Grace','Rue Tabaga',75010,'Paris','No comment'),
(17,'Monsieur','Liguyli','Guy','Rue Ral',92500,'Rueil-Malmaison','No comment'),
(18,'Mademoiselle','Greux','Nadine','Rue Dimentaire',92000,'Nanterre','No comment'),
(19,'Mademoiselle','HAN-NIVISKEU','Nicole','Rue Niforme',75020,'Paris','No comment'),
(20,'Madame','DIKULISAI','Valérie','Rue Raux',78100,'St Germain En Laye','No comment'),
(21,'Mademoiselle','GOUDY','Debbie','Rue Fian',92360,'Meudon','No comment'),
(22,'Mademoiselle','Maidine','France','Rue Hisso',69001,'Lyon','No comment'),
(23,'Monsieur','Hoposte','Fidèle','Rue Doyer',69003,'Lyon','No comment');
/*!40000 ALTER TABLE `client` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commande`
--

DROP TABLE IF EXISTS `commande`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commande` (
  `NCommande` tinyint(3) NOT NULL,
  `NClient` tinyint(3) DEFAULT NULL,
  `DateCommande` date DEFAULT NULL,
  `CommandeReglee` enum('oui','non') DEFAULT NULL,
  `NVendeur` tinyint(2) DEFAULT NULL,
  PRIMARY KEY (`NCommande`),
  KEY `fk_commande` (`NClient`),
  CONSTRAINT `fk_commande` FOREIGN KEY (`NClient`) REFERENCES `client` (`NClient`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commande`
--

LOCK TABLES `commande` WRITE;
/*!40000 ALTER TABLE `commande` DISABLE KEYS */;
INSERT INTO `commande` VALUES
(1,1,'2007-12-24','oui',1),
(2,2,'2007-12-08','non',2),
(3,3,'2007-12-08','oui',3),
(4,4,'2008-03-17','non',3),
(5,4,'2009-01-12','oui',2),
(6,5,'2009-02-12','oui',2),
(7,6,'2009-10-12','oui',2),
(8,6,'2009-12-12','oui',2),
(9,7,'2009-11-03','oui',1),
(10,3,'2009-11-14','oui',2),
(11,3,'2009-12-15','oui',1),
(12,15,'2009-12-15','oui',2),
(13,17,'2009-12-15','oui',3),
(14,9,'2009-12-16','oui',1),
(15,14,'2009-12-16','oui',1),
(16,8,'2009-12-16','oui',2),
(17,12,'2009-12-16','oui',3),
(18,12,'2009-12-17','oui',1),
(19,13,'2009-12-16','oui',1),
(20,19,'2009-12-18','oui',1),
(21,20,'2009-12-19','oui',2),
(22,20,'2010-01-07','oui',1),
(23,21,'2010-01-09','oui',1),
(24,22,'2010-01-09','oui',1),
(25,23,'2010-01-09','oui',2),
(26,4,'2010-01-10','oui',1),
(27,5,'2010-01-11','oui',3),
(28,6,'2010-01-15','oui',1),
(29,6,'2010-01-16','oui',2),
(30,7,'2010-01-19','non',1),
(31,16,'2010-02-14','oui',2),
(32,20,'2010-02-14','oui',1),
(33,4,'2010-02-14','oui',3),
(34,5,'2010-02-14','oui',1),
(35,15,'2010-02-15','oui',1),
(36,21,'2010-02-15','oui',1),
(37,23,'2010-02-15','oui',1),
(38,1,'2010-02-16','oui',3),
(39,9,'2010-02-17','oui',1),
(40,1,'2010-02-18','oui',1),
(41,3,'2010-03-15','oui',1),
(42,6,'2010-03-16','oui',1),
(43,13,'2010-03-18','oui',1),
(44,18,'2010-03-18','oui',2),
(45,2,'2010-03-20','oui',1),
(46,15,'2010-03-25','oui',1),
(47,19,'2010-03-26','oui',2);
/*!40000 ALTER TABLE `commande` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fournisseur`
--

DROP TABLE IF EXISTS `fournisseur`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fournisseur` (
  `NFournisseur` tinyint(3) NOT NULL AUTO_INCREMENT,
  `Societe` char(20) NOT NULL DEFAULT '',
  `Titre` enum('Madame','Mademoiselle','Monsieur') DEFAULT NULL,
  `Nom` char(30) DEFAULT NULL,
  `Prenom` char(30) DEFAULT NULL,
  `Adresse` char(100) DEFAULT NULL,
  `CodePostal` float(5,0) unsigned zerofill DEFAULT NULL,
  `Ville` char(20) DEFAULT NULL,
  `Telephone` char(15) DEFAULT NULL,
  `Fax` char(15) DEFAULT NULL,
  `Observation` text DEFAULT NULL,
  PRIMARY KEY (`NFournisseur`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fournisseur`
--

LOCK TABLES `fournisseur` WRITE;
/*!40000 ALTER TABLE `fournisseur` DISABLE KEYS */;
INSERT INTO `fournisseur` VALUES
(1,'Livregratuit','Monsieur','Kiroule','Pierre','rue du Capital',13001,'Marseilles','0402030405','0402030455','\r\n'),
(2,'Livrepachere','Monsieur','Monfils','Thibeault','Bd du Choix',92000,'Nanterre','0145566778','0145566777','\r\n'),
(3,'Livrepresktou','Mademoiselle','Lot','Samantha','avenue du Pont',75006,'Paris','0123456789','0123456799','\r\n');
/*!40000 ALTER TABLE `fournisseur` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fournisseurproduit`
--

DROP TABLE IF EXISTS `fournisseurproduit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fournisseurproduit` (
  `NFournisseur` tinyint(3) NOT NULL,
  `CodeProduit` tinyint(3) NOT NULL,
  PRIMARY KEY (`NFournisseur`,`CodeProduit`),
  KEY `fk_fournisseurproduit2` (`CodeProduit`),
  CONSTRAINT `fk_fournisseurproduit1` FOREIGN KEY (`NFournisseur`) REFERENCES `fournisseur` (`NFournisseur`) ON DELETE CASCADE,
  CONSTRAINT `fk_fournisseurproduit2` FOREIGN KEY (`CodeProduit`) REFERENCES `produit` (`CodeProduit`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fournisseurproduit`
--

LOCK TABLES `fournisseurproduit` WRITE;
/*!40000 ALTER TABLE `fournisseurproduit` DISABLE KEYS */;
INSERT INTO `fournisseurproduit` VALUES
(1,1),
(1,2),
(1,3),
(1,4),
(1,5),
(1,10),
(1,11),
(1,12),
(1,13),
(1,14),
(1,15),
(2,2),
(2,6),
(2,7),
(2,8),
(2,9),
(2,10),
(2,12),
(3,3),
(3,11),
(3,12),
(3,13),
(3,14),
(3,15);
/*!40000 ALTER TABLE `fournisseurproduit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lignecommande`
--

DROP TABLE IF EXISTS `lignecommande`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lignecommande` (
  `NCommande` tinyint(3) NOT NULL,
  `CodeProduit` tinyint(3) NOT NULL,
  `Quantite` tinyint(3) DEFAULT NULL,
  PRIMARY KEY (`NCommande`,`CodeProduit`),
  KEY `fk_lignecommande2` (`CodeProduit`),
  CONSTRAINT `fk_lignecommande1` FOREIGN KEY (`NCommande`) REFERENCES `commande` (`NCommande`) ON DELETE CASCADE,
  CONSTRAINT `fk_lignecommande2` FOREIGN KEY (`CodeProduit`) REFERENCES `produit` (`CodeProduit`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lignecommande`
--

LOCK TABLES `lignecommande` WRITE;
/*!40000 ALTER TABLE `lignecommande` DISABLE KEYS */;
INSERT INTO `lignecommande` VALUES
(1,1,2),
(1,2,1),
(2,3,3),
(3,12,2),
(3,14,1),
(4,8,4),
(4,9,5),
(5,5,10),
(5,12,6),
(6,6,3),
(6,7,1),
(7,8,4),
(7,9,1),
(8,5,5),
(9,7,2),
(10,10,4),
(10,11,2),
(10,12,1),
(11,2,1),
(11,5,3),
(12,1,1),
(12,7,1),
(12,14,2),
(13,9,2),
(14,14,2),
(15,3,2),
(16,7,1),
(16,8,2),
(17,11,1),
(18,1,1),
(19,9,5),
(20,9,2),
(21,1,5),
(21,2,2),
(21,3,3),
(22,11,2),
(23,4,2),
(24,4,1),
(25,5,2),
(26,6,3),
(27,7,3),
(28,8,1),
(29,9,10),
(30,3,2),
(31,1,3),
(31,3,1),
(32,3,2),
(33,3,3),
(34,4,3),
(35,12,20),
(36,13,3),
(37,14,1),
(38,8,3),
(39,12,2),
(39,14,1),
(39,15,1),
(40,4,1),
(40,7,2),
(41,1,4),
(41,12,1),
(42,13,2),
(43,14,3),
(44,7,2),
(44,8,8),
(45,4,2),
(45,5,1),
(46,11,2),
(47,15,2);
/*!40000 ALTER TABLE `lignecommande` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `produit`
--

DROP TABLE IF EXISTS `produit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `produit` (
  `CodeProduit` tinyint(3) NOT NULL,
  `Designation` char(50) DEFAULT NULL,
  `PrixUnitaire` float(5,2) DEFAULT NULL,
  `TauxTva` float(4,3) DEFAULT NULL,
  `Stock` int(5) DEFAULT NULL,
  PRIMARY KEY (`CodeProduit`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `produit`
--

LOCK TABLES `produit` WRITE;
/*!40000 ALTER TABLE `produit` DISABLE KEYS */;
INSERT INTO `produit` VALUES
(1,'Prod01',15.00,0.196,1000),
(2,'Prod02',25.00,0.055,1000),
(3,'Prod03',35.00,0.055,1000),
(4,'Prod04',45.00,0.196,1000),
(5,'Prod05',55.00,0.196,1000),
(6,'Prod06',65.00,0.055,1000),
(7,'Prod07',75.00,0.055,1000),
(8,'Prod08',85.00,0.055,1000),
(9,'Prod09',95.00,0.055,1000),
(10,'Prod10',100.00,0.055,1000),
(11,'Prod11',110.00,0.196,1000),
(12,'Prod12',120.00,0.196,1000),
(13,'Prod13',130.00,0.196,1000),
(14,'Prod14',140.00,0.196,1000),
(15,'Prod15',150.00,0.196,1000);
/*!40000 ALTER TABLE `produit` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-01-19 12:56:19
