<html>
	<head>
		<link rel="stylesheet" href="index.css" title="CSS global">
	</head>
<body>

<form action="article.php" method="get">
<table>
<tr><td>*</td><td>Nom : </td><td><input type="text" name="auteur" /></td>
<td><input name="" type="submit" value="Envoyer" /></td></tr>
</table>

</form>

</body>
</html>