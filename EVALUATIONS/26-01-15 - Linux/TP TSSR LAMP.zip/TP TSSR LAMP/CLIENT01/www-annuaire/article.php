<html>
	<head>
		<link rel="stylesheet" href="index.css" title="CSS global">
	</head>
<body>
<h1 align=center>
<?php
echo 'bonjour '.$_GET['auteur'] ;
?>
</h1>
</body>

</html>